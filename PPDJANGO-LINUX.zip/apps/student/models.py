from django.db import models

class Student(models.Model):
    name = models.CharField(max_length=100, verbose_name="Nombre")
    last_name = models.CharField(max_length=100, verbose_name="Apellido")
    email = models.EmailField(max_length=254,unique = True, verbose_name="Email")
    age = models.IntegerField(verbose_name="Edad")

    def __str__(self):
        return f'{self.name} {self.last_name}'

    class Meta:
        ordering = ['name', 'last_name']