from django.shortcuts import render
from django.urls import reverse_lazy
from django.views.generic import CreateView

from apps.student.forms import StudentForm
from apps.student.models import Student

# Create your views here.

class AddStudent(CreateView):
    model = Student
    form_class = StudentForm
    template_name = 'student/add_student.html'
    success_url = reverse_lazy('add_student')

    def get_context_data(self, **kwargs):
        context = super(AddStudent, self).get_context_data(**kwargs)
        context['object_list'] = self.model.objects.all()
        return context
