from django import forms

from apps.student.models import Student


class StudentForm(forms.ModelForm):

    name = forms.CharField(
        label='Nombre', 
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder':"Ingresar nombre",
        })
    )

    last_name = forms.CharField(
        label='Apellido', 
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder':"Ingresar apellido",
        })
    )


    email = forms.EmailField(
        label='Email', 
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder':'Ingresar E-mail',
            'autocomplete': 'off',
            
        })
    )

    age = forms.IntegerField(
        label='Edad',
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder':'Ingresar edad',
            'autocomplete': 'off'
        })
    )

    

    class Meta:
        model = Student
        fields='__all__'